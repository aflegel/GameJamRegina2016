To load and edit our project, you need Unity 5.3 and Visual Studio 2015 Community. 
1. Load the Unity project in Unity 5.3
2. Double click on a .cs file in the Assets to load the project into Visual Studio 2015. 
3. To Build use the Unity Build option under >File