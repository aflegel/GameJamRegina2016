# CultSimulator2016
- Unity
- VS 2015

## Global Game Jam link
The game can be found on the Global Game Jam site [here](http://globalgamejam.org/2016/games/cultsimulator2016)