﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets.CultSimulator
{
	public class PersonReference
	{
		public int PersonID { get; set; }
		public bool IndepthInvestigated { get; set; }
	}
}
