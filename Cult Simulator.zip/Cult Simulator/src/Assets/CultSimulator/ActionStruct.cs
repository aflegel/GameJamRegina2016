﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets.CultSimulator
{
	public enum ActionType
	{
		None = 0,
		Investigate = 1,
		Abduct = 2,
		Recruit = 3,
	}
}
